public interface Admin extends User{
    void setBalance(double balance);
}
