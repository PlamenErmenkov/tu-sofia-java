public interface User {
    double getBalance();
}
