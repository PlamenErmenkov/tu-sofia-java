public class App {
    public static void main(String[] args) {
//        Bank bank = new Bank(5000);
//        bank.getBalance();
//        bank.setBalance(20);

        Admin admin = new Bank(2900);
        User user = admin;

        System.out.println(user.getBalance()+" this is before updating the balance (user)");
        admin.setBalance(admin.getBalance() + 200);

        System.out.println(user.getBalance()+" this is after updating the balance (user)");
        System.out.println(admin.getBalance()+" This is admin");

        //user.setBalance(300);
    }
}